name ='fadi wedyan'
name2 = name.title()
print( name2)
