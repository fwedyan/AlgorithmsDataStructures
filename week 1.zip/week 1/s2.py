str = 'welcome to whatever you are welcomed to!'
words = [ ]
words = str.split()
print(words)
